package com.mvc.mapper;

import com.entity.User;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface UserMapper {
    @Results(value = {
            @Result(column = "u_id", property = "id"),
            @Result(column = "u_username", property = "username"),
            @Result(column = "u_password", property = "password")
    })
    @Select("select * from user")
    public List<User> getAll();
}
